Harvest Geek Sensor Station V1.1
Engineer: Rowan Gifford
Contact: rowan.gifford@gmail.com
Tel: +447979880940
Date: 03 July 2014

2 layer PTH 1.6mm FR4 1 oz Cu I.S. Every day service

PCB size: 93.88mm x 43.92mm

Files:

SENSORSTATION_BOARD_OUTLINE.gbr - PCB outline, standard 2mm router, no panalisation
SENSORSTATION_BOTMASK.gbs - Bottom layer solder mask
SENSORSTATION_BOTTOM.gbl - Bottom copper layer
SENSORSTATION_TOPMASK.gts - Top layer solder mask
SENSORSTATION_TOP.gtl - Top copper layer
SENSORSTATION_SILKTOP.gto - Top layer silkscreen
SENSORSTATION_DRILL.drl - Drill file, all plated through hole.
SENSORSTATION_ASSY.gto - Assembly file, shows component placement and references