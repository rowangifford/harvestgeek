Harvest Geek Moisture Probe V1.0
Engineer: Rowan Gifford
Contact: rowan.gifford@gmail.com
Date: 16th June 2015

2 layer PTH 1.6mm FR4 1 oz Cu ENIG
PCB size: 21mm x 64mm

(FOLDER) moisture_probe_rev1.0_manufacturing_files - Manufacturing data, Gerbers, Drill file, position file and assy. See README
(FILE) BoM_MoistureProbe_Rev1.0.xlsm - Bill of materials