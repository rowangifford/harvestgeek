Files:

basestation_rev1.2_manufacturing_files (Folder) - Contains PCB gerbers, pick & place position and assembly diagram. See REARME.txt in folder.
Base Station Assembly Guide.pdf - Guide to final enclosure assembly
base_station_PCB_guide.pdf - PCB assembly guide, contains info in SMD components, pin one locations
base_station_TEST_procedure.pdf - Power on test procedure
BoM_BaseStation_Rev1.2.xlsm - Bill of materials